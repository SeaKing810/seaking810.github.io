#!/bin/sh
# Sean McKenna | CS 499 | November 7, 2026. Runs original and enhanced JUnit suites.
set -eu
cd "$(dirname "$0")"
sh build.sh
mkdir -p build/test build/original build/reports/enhanced build/reports/original
find src/test/java -name '*.java' | sort > build/test-sources.txt
javac --release 17 -encoding UTF-8 -Xlint:all -cp 'build/main:lib/*' -d build/test @build/test-sources.txt
javac --release 17 -encoding UTF-8 -cp 'lib/*' -d build/original ../original/*.java
java -jar lib/junit-platform-console-standalone-1.12.2.jar execute --disable-banner --disable-ansi-colors \
  --class-path build/original --scan-class-path --fail-if-no-tests \
  --reports-dir build/reports/original
java -jar lib/junit-platform-console-standalone-1.12.2.jar execute --disable-banner --disable-ansi-colors \
  --class-path 'build/main:build/test:lib/gson-2.14.0.jar' --scan-class-path --fail-if-no-tests \
  --reports-dir build/reports/enhanced
