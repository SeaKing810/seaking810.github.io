#!/bin/sh
# Sean McKenna | CS 499 | November 7, 2026. Offline Java 17-compatible build.
set -eu
cd "$(dirname "$0")"
mkdir -p build/main
find src/main/java -name '*.java' | sort > build/main-sources.txt
javac --release 17 -encoding UTF-8 -Xlint:all -cp 'lib/*' -d build/main @build/main-sources.txt
