#!/bin/sh
# Sean McKenna | CS 499 | November 7, 2026. Starts the local contact application.
set -eu
cd "$(dirname "$0")"
sh build.sh
java -cp 'build/main:lib/*' edu.snhu.contactmanager.Main "$@"
